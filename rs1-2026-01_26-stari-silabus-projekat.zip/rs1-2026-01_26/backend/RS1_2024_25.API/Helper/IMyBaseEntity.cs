﻿namespace RS1_2024_25.API.Helper;

public interface IMyBaseEntity
{
    public int ID { get; set; }
}
