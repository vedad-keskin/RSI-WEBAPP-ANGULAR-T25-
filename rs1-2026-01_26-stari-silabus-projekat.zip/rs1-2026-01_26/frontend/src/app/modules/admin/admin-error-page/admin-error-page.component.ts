import {Component} from '@angular/core';

@Component({
  selector: 'app-admin-error-page',
  templateUrl: './admin-error-page.component.html',
  styleUrl: './admin-error-page.component.css',
  standalone: false
})
export class AdminErrorPageComponent {

}
