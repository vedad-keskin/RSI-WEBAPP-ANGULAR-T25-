export class MyConfig {
  static api_address = "http://localhost:7000"
}
