export interface MyPagedRequest {
  pageNumber: number;
  pageSize: number;
}

