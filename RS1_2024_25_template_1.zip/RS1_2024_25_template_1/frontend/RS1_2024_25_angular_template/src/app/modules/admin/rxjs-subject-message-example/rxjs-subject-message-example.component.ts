import { Component } from '@angular/core';

@Component({
  selector: 'app-rxjs-subject-message-example',
  standalone: false,
  
  templateUrl: './rxjs-subject-message-example.component.html',
  styleUrl: './rxjs-subject-message-example.component.css'
})
export class RxjsSubjectMessageExampleComponent {

}
