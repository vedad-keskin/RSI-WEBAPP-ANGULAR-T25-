import {Component} from '@angular/core';

@Component({
  selector: 'app-destination',
  templateUrl: './destination.component.html',
  styleUrl: './destination.component.css',
  standalone: false
})
export class DestinationComponent {

}
