import {Component} from '@angular/core';

@Component({
  selector: 'app-public-layout',
  templateUrl: './public-layout.component.html',
  styleUrl: './public-layout.component.css',
  standalone: false
})
export class PublicLayoutComponent {

}
