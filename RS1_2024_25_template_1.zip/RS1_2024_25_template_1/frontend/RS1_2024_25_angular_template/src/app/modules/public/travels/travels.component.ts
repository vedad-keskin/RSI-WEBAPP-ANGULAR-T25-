import {Component} from '@angular/core';

@Component({
  selector: 'app-travels',
  templateUrl: './travels.component.html',
  styleUrl: './travels.component.css',
  standalone: false
})
export class TravelsComponent {

}
