﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RS1_2024_25.API.Helper.BaseClasses;

public abstract class SharedTableBase : BaseEntity
{
    //shared reference tabeles, distriubited on all nodes
}
